import { Product } from 'src/app/products/service/product.model';
import { productsData } from 'src/app/products/service/products.data';

export const popularProductsData: Product[] = productsData.slice();
