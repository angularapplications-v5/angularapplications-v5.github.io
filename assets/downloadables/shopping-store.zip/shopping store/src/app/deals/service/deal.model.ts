export interface Deal {
  id: string;
  imageUrl: string;
  dealUrl: string;
}
