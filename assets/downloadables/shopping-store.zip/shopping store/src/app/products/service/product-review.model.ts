export interface ProductReview {
  productId: string;
  username: string;
  title: string;
  content: string;
  rating: string;
  reviewDate: string;
}
