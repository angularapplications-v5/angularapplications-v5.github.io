export const productDeliveryRelationshipData: {
  productId: string;
  value: string;
}[] = [
  { productId: '8347836c-35db-4307-ac5d-cbdf19a9a50c', value: '15' },
  { productId: 'f8c2cc34-ddb7-46ec-96ee-e27d1765df10', value: '15' },
  { productId: '2927b969-1c97-4a36-b4ab-a0777d8690e2', value: '15' },
];
