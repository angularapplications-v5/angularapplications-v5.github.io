export const productDiscountRelationshipData: {
  productId: string;
  value: string;
}[] = [
  { productId: '8347836c-35db-4307-ac5d-cbdf19a9a50c', value: '15' },
  { productId: 'f8c2cc34-ddb7-46ec-96ee-e27d1765df10', value: '5' },
  { productId: '2927b969-1c97-4a36-b4ab-a0777d8690e2', value: '25' },
  { productId: '57ba7441-8bea-4340-9f49-dc369d108cf7', value: '5' },
  { productId: '552809ab-7ea3-4e48-be23-3c7c53219284', value: '5' },
  { productId: '893deaf7-5224-4702-9ba6-4fc4c52bed22', value: '10' },
];
