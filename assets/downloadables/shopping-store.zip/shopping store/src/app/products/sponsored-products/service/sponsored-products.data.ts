import { Product } from '../../service/product.model';
import { productsData } from '../../service/products.data';

export const sponsoredProductsData: Product[] = productsData.slice();
