import { Product } from '../../service/product.model';
import { productsData } from '../../service/products.data';

export const customersViewedProductsData: Product[] = productsData.slice();
