import { Product } from "../../service/product.model";
import { productsData } from "../../service/products.data";

export const customersBoughtProductsData: Product[] = productsData.slice();
