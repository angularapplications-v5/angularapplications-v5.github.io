import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-first-footer',
  templateUrl: './first-footer.component.html',
  styleUrls: ['./first-footer.component.css']
})
export class FirstFooterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
