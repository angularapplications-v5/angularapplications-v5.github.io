export const productCategoryRelationshipData: {
  productId: string;
  categoryId: string;
}[] = [
  {
    categoryId: '0481b006-103e-4dcc-aa37-a8ad2adaff44',
    productId: 'a8434cd4-7898-4c62-85bb-a96798397a60',
  },
  {
    categoryId: '0481b006-103e-4dcc-aa37-a8ad2adaff44',
    productId: '600d3a00-a71e-478a-adca-aca13157341d',
  },
  {
    categoryId: '0481b006-103e-4dcc-aa37-a8ad2adaff44',
    productId: '02be05a5-697f-4dfc-9099-acf7695c2cac',
  },
  {
    categoryId: '0481b006-103e-4dcc-aa37-a8ad2adaff44',
    productId: '2b662a32-a474-4f06-8cb0-5c3c9c2b6f3f',
  },
  {
    categoryId: '0481b006-103e-4dcc-aa37-a8ad2adaff44',
    productId: '50f2cbe8-16f8-4bae-b12c-d5932c881e96',
  },
  {
    categoryId: '0481b006-103e-4dcc-aa37-a8ad2adaff44',
    productId: '46c79cbf-40e0-4921-b608-e7f9ebf51bd5',
  },
  {
    categoryId: '0481b006-103e-4dcc-aa37-a8ad2adaff44',
    productId: '5400669f-128f-4c41-8eab-c3722946f5f1',
  },
  {
    categoryId: '0481b006-103e-4dcc-aa37-a8ad2adaff44',
    productId: '0cc62540-7965-4e57-a424-f38bff67450f',
  },
  {
    categoryId: '0481b006-103e-4dcc-aa37-a8ad2adaff44',
    productId: '60e8dc08-afc3-460b-973a-f07a176ff6f0',
  },
  {
    categoryId: '0481b006-103e-4dcc-aa37-a8ad2adaff44',
    productId: '1217d68b-2c8d-44a1-a068-1ab0b4423941',
  },
  {
    categoryId: '0481b006-103e-4dcc-aa37-a8ad2adaff44',
    productId: '3d3b43a2-2129-405a-a5b3-83a1d7b258e7',
  },
  {
    categoryId: '0481b006-103e-4dcc-aa37-a8ad2adaff44',
    productId: '442cc5be-9677-4abf-9277-f0a264e38df1',
  },
  {
    categoryId: '0481b006-103e-4dcc-aa37-a8ad2adaff44',
    productId: '69f37fd6-e263-4409-a0f6-29623cbe78a4',
  },
  {
    categoryId: '0481b006-103e-4dcc-aa37-a8ad2adaff44',
    productId: '3d042d3b-1299-40f2-82a3-babc3477eeac',
  },
  {
    categoryId: '0481b006-103e-4dcc-aa37-a8ad2adaff44',
    productId: 'd8098404-ff49-45f6-9b70-64bf6300b27d',
  },
];
