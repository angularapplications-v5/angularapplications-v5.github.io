export interface ProductFilterItem {
  name: string;
  checked: boolean;
}
