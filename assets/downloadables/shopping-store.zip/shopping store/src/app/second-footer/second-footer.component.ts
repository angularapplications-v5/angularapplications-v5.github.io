import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-second-footer',
  templateUrl: './second-footer.component.html',
  styleUrls: ['./second-footer.component.css'],
})
export class SecondFooterComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}

  get year() {
    return new Date().getFullYear().toString();
  }
}
