export interface TopInCategory {
  id: string,
  title: string,
  imageUrl: string,
  url: string
}
