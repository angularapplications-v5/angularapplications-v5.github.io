export interface Sale {
  id: string,
  imageUrl: string,
  url: string
}
