import { Cart } from './cart.model';

export const cartData: Cart = {
  id: '5f3787e7-bca6-4ee3-809a-53e0bdd94368',
  subtotal: '0',
  deliveryTotal: '0',
  total: '0',
  items: [],
};
